<?php
/**
 * @copyright    Copyright (C) 2020 Marsel Shaikamalov. All rights reserved.
 * @license      GNU General Public License version 2 or later; see LICENSE.txt
 */

defined( '_JEXEC' ) or die;

/**
 * @package plugin jshoppingEMT
 * @copyright (C) 2010-2013 Emailtoools
 * @license http://www.gnu.org/copyleft/gpl.html GNU/GPL
 */

defined('_JEXEC') or die('Restricted access');

class EMTApi
{

    protected $apiKey;
    protected $tracker_url = 'https://emailtools.ru/tracker/';
    protected $timeout;
    protected $origin;

    public function __construct($apiKey, $timeout = 3)
    {
        $this->apiKey = $apiKey;
        $this->timeout = $timeout;
        $this->origin = 'http' . ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == 'on') ? 's' : '') . '://' . $_SERVER ['HTTP_HOST'];
    }

    public function sendOperation($task, $param)
    {
        if (empty($_COOKIE["emt_uuuid"]) || !isset($_COOKIE["emt_uuuid"])) {
            $uuuid = uniqid();  // or use a real UUID
            setcookie('firstvisit', 1);
            setcookie("emt_uuuid", $uuuid, time()+30*24*60*60, "/");
        }
        else {
            $uuuid = $_COOKIE["emt_uuuid"];
        }
        if(!isset($_COOKIE['emt_uuuid']) || empty($_COOKIE['emt_uuuid'])) return 'error uuuid cookie';

        $param['client_id'] = $this->apiKey;
        $param['uuuid'] = $_COOKIE['emt_uuuid'];
        $param['task'] = $task;

        if (!isset($_COOKIE['emt_uuuid'])) return 'Bad uuid';

        $curl = curl_init($this->tracker_url);

        curl_setopt_array($curl, [
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_HTTPHEADER =>  [
                'Content-Type: application/x-www-form-urlencoded',
                'Accept: */*',
                'Origin: '.$this->origin,
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($param),
            CURLOPT_TIMEOUT => $this->timeout
        ]);

        $response = curl_exec($curl);
        curl_close($curl);

        return $response;
    }

}

class plgVmCustomEmailtools extends vmCustomPlugin
{
	private $apikey;
	private $addLogger;
	private $resizable;
	function __construct(& $subject, $config) {

		parent::__construct($subject, $config);
		
		$this->apikey = $this->params->get('apikey', 0);//код клиента / EMT API KEY в личном кабинете emailtools
		
		$this->addLogger = $this->params->get('addlogs', 0);
		
		$this->resizable = false;

	}
	//добавляем скрипты в head
	public function onBeforeCompileHead()
    {

        if($this->params->get('terms_and_conditions' , 0) == 1){
        $document = JFactory::getDocument();
        $document->addCustomTag('<script src="https://emailtools.ru/js/api/v1.1/tools.js" defer= "" async=""></script>');
        if ($this->params->get('character') == false) {
            $document->addCustomTag('<script>window.EMT = window.EMT || {};EMT._client_id = ' . $this->apikey . ';</script>');
        } else {
            $document->addCustomTag('<script>window.EMT = window.EMT || {};EMT._client_id = ' . $this->apikey . '; EMT._character = "v1"; </script>');
        }
        $document = JFactory::getDocument();
        $emt = new EMTApi($this->params->get('apikey', 0));
        $jinput = JFactory::getApplication()->input;
        if (!$this->resizable) {
            $this->resizable = true;
            $temp = explode(':', $jinput->getCmd('view'));
            $temp1 = explode(':', $jinput->getCmd('virtuemart_category_id'));
            $if_category = $temp[0];
            $category_id = $temp1[0];
            // Пользователь просматривает категорию
            if($if_category == "category"){
                $document->addCustomTag('<script src="https://emailtools.ru/js/api/v1.1/tools.js" defer= "" async=""></script>');
                if ($this->params->get('character') == false) {
                    $document->addCustomTag('<script>window.EMT = window.EMT || {};EMT._client_id = ' . $this->apikey . ';</script>');
                } else {
                    $document->addCustomTag('<script>window.EMT = window.EMT || {};EMT._client_id = ' . $this->apikey . '; EMT._character = "v1"; </script>');
                }
                $document->addCustomTag('<script type="text/javascript"> window.EMT || {}; EMT.operation={"task" : "viewCategory","categoryid" : '.$category_id.'};</script>');
                if($this->params->get('addlogs' , 0) == 1){
                    if( $result = $emt->sendOperation('viewCategory', array('categoryid'=>$category_id)) == "View category" || $result = $emt->sendOperation('viewCategory', array('categoryid'=>$category_id)) == "Update view category") {
                        $this->setLog($result = $emt->sendOperation('viewCategory', array('categoryid'=>$category_id)));
                    }
                }
                return true;
            }

            //Пользователь удалил товар из корзины
            if($if_category == "cart"){
                $session = JFactory::getSession();
                $cartSession = $session->get('vmcart', 0, 'vm'); // получаем коризну
                $nikolaevevgeCart = json_decode($cartSession); // декодируем в массив
                $count=0;
                if(!isset($_SESSION['old_cart']) || empty($_SESSION['old_cart'])){ // проверяем, сущетсвует ли товары в коризне
                    $_SESSION['old_cart'] = array();
                }
                foreach($nikolaevevgeCart->cartProductsData as $value){
                    $newcart[$count] = $value->virtuemart_product_id; // формируем новую корзину, с учетом добавленного товара
                    $count++;
                }
                if(count($_SESSION['old_cart']) > count($newcart)){
                    if(count($_SESSION['old_cart']) == 1){ // если это первый добавленный, и он же удаленный, товар
                        $diff = $_SESSION['old_cart'][0];
                        $_SESSION['old_cart'] = array(); // удален удинсвтенный товар
                    }else{ // если в корзине не один товар
                        $diff = array_diff($_SESSION['old_cart'], $newcart); // находим отличия между корзиной до удаления товара и после
                    }
                    if($diff) {
                        $product_id = $diff[0];
                        $emt = new EMTApi($this->params->get('apikey', 0));
                        $jinput = JFactory::getApplication()->input;
                        $result = $emt->sendOperation('removeproduct', array('productid' => $product_id));
                        if($this->params->get('addlogs' , 0) == 1){
                            $this->setLog($result);
                        }
                    }
                }
                $count=0;
                unset($_SESSION['old_cart']);
                if(empty($nikolaevevgeCart->cartProductsData)) {
                    $_SESSION['old_cart'] = array();
                }else{
                    foreach($nikolaevevgeCart->cartProductsData as $value){
                        $_SESSION['old_cart'][$count] = $value->virtuemart_product_id;
                        $count++;
                    }}
                return true;
            }}
            return;
        }}
	//Пользователь добавил товар в корзину
	public function plgVmOnAddToCart($product)
	{
        if($this->params->get('terms_and_conditions' , 0) == 1){
		$emt = new EMTApi($this->params->get('apikey', 0));
		$current_product = $product->cartProductsData[0];
		$product_id = $current_product['virtuemart_product_id'];
		$result = $emt->sendOperation('addtocart', array('productid' => $product_id));	
		if($this->params->get('addlogs' , 0) == 1){
			$this->setLog($result);
			}
		return true;
	}}
	//Пользователь оформил заказ
	public function plgVmConfirmedOrder($order_info) {
        if($this->params->get('terms_and_conditions' , 0) == 1){
		$client_mail=$order_info->BT['email'];
		$emt = new EMTApi($this->params->get('apikey', 0));
		$jinput = JFactory::getApplication()->input;
		if(isset($client_mail)){
		$result = $emt->sendOperation('onlinepay', array('email' => $client_mail));	
		if($this->params->get('addlogs' , 0) == 1){
			$this->setLog($result);
			}
		}
		$products_order = array();
		$count = 0;
		foreach($order_info->products as $value){
			$products_order[$count] = $value->virtuemart_product_id;
			$count++;
		}
		$params = array(
		'name' =>trim(implode(' ',[$order_info->BT['first_name'], $order_info->BT['last_name']])),
		'email' => $client_mail,
		'orderid' => $order_info->orderDetails['details']['BT']->virtuemart_order_id,
		'products' => $products_order,
		'total' => (int)$order_info->cartPrices['billTotal'],
		//'permission' => 'subscribe' // unsubscribe
		);
		$result = $emt->sendOperation('sendOrder',$params);	
		if($this->params->get('addlogs' , 0) == 1){
			$this->setLog($result);
			}
		return true;
	}}
	//пользователь просматривает товар
	public function plgVmOnProductDisplayShipment ($product){
        if($this->params->get('terms_and_conditions' , 0) == 1){
		$document = JFactory::getDocument();
		$product_id=$product->prices['virtuemart_product_id'];
		$document->addCustomTag('<script src="https://emailtools.ru/js/api/v1.1/tools.js" defer= "" async=""></script>');
        if ($this->params->get('character') == false) {
            $document->addCustomTag('<script>window.EMT = window.EMT || {};EMT._client_id = ' . $this->apikey . ';</script>');
        } else {
            $document->addCustomTag('<script>window.EMT = window.EMT || {};EMT._client_id = ' . $this->apikey . '; EMT._character = "v1"; </script>');
        }
		$document->addCustomTag('<script type="text/javascript"> window.EMT || {}; EMT.operation={"task" : "viewProduct","productid" : '.$product_id.'};</script>');
		$emt = new EMTApi($this->params->get('apikey', 0));
		if($this->params->get('addlogs' , 0) == 1){
            if($result = $emt->sendOperation('viewProduct', array('categoryid'=>$product->categoryItem[0]['virtuemart_category_id'], 'productid'=>$product_id)) == "View product" || $result = $emt->sendOperation('viewProduct', array('categoryid'=>$product->categoryItem[0]['virtuemart_category_id'], 'productid'=>$product_id)) == "Update view product"){
                $this->setLog($result = $emt->sendOperation('viewProduct', array('categoryid'=>$product->categoryItem[0]['virtuemart_category_id'], 'productid'=>$product_id)));
            }

        }

		return true;
	}}

	//Функция логов
			function setLog ($message, $type = 'JLog:ALL' , $category = 'vmcustom'){
			jimport('joomla.log.logger.formattedtext');
			$options = array( 'text_file' => 'emtlogs.txt', 'text_file_path' => JPATH_PLUGINS.'/vmcustom/emailtools/logs/', 'text_file_no_php' => true, 'text_entry_format' => '' );
			$logger = new JLogLoggerFormattedtext( $options );
			$log = new JLogEntry( $message, $type = 'JLog:ALL' , $category, '', array() );
			$logger->addEntry( $log );
			return true;

	}
}

?>